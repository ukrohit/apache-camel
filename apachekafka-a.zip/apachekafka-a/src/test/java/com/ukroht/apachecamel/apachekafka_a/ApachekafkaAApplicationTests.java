package com.ukroht.apachecamel.apachekafka_a;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApachekafkaAApplicationTests {

	@Test
	void contextLoads() {
	}

}
