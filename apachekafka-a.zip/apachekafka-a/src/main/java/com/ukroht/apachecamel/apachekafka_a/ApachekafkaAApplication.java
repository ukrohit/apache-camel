package com.ukroht.apachecamel.apachekafka_a;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApachekafkaAApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApachekafkaAApplication.class, args);
	}

}
