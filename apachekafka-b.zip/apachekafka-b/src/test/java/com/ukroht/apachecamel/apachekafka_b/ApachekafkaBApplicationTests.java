package com.ukroht.apachecamel.apachekafka_b;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApachekafkaBApplicationTests {

	@Test
	void contextLoads() {
	}

}
