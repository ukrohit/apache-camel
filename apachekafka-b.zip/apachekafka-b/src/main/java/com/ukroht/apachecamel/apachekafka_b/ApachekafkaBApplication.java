package com.ukroht.apachecamel.apachekafka_b;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApachekafkaBApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApachekafkaBApplication.class, args);
	}

}
